export interface Comment {
    id: string;
    content: string;
    author: string;
    projectId: string;
    createdAt: string;
}
