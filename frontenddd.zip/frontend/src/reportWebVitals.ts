// src/reportWebVitals.ts

const reportWebVitals = (metric: any) => {
  console.log(metric);
};

export default reportWebVitals;
